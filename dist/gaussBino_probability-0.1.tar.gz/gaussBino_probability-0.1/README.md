this package is for calculating:- 
1. Gaussian distributoin for given data set
2. Binomial distributoin for given data set

it also shows Histogram and graph representation.

