from setuptools import setup

setup(name='gaussBino_probability',
      version='0.1',
      description='Gaussian distributions',
      auther='krishna kumar',
      packages=['gaussBino_probability'],
      zip_safe=False)
